#!/bin/bash

docker build -t jmessage/server .
