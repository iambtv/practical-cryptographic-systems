#!/bin/bash

java -jar /app/jmessage.jar -p 80 -s 127.0.0.1 -u bob -m alice
