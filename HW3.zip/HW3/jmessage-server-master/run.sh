#!/bin/bash

docker run -d --name 650.445 --name jmessage -p 80:80 jmessage/server
